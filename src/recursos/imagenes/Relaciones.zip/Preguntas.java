/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author 
 */
public class Preguntas {
    public static void main(String[] args) {
    ArrayList<Pregunta> listaPreg = new ArrayList();
    
    //Pregunta 37
    ArrayList<String> opciones = new ArrayList();
    String enunciado37="Indique cual de las siguientes opciones contiene propiedades de Relaciones: ";
    String opcionA= "Conmutativa, reflexiva, transitiva";
    String opcionB= "Antisimétrica, reflexiva, distributiva";
    String opcionC= "Reflexiva, antisimétrica, transitiva";
    String opcionD= "Reflexiva, antisimétrica, asociativa";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg37 = new Pregunta (enunciado1, opciones, "Reflexiva, antisimétrica, transitiva", "Facil", "Relaciones");
    listaPreg.add(preg37);
    
    //Pregunta 38
    opciones = new ArrayList();
    String enunciado38="A que propiedad pertenece la siguiente definición : Para toda x, y ∈ X, si (x, y) ∈ R y x ≠ y, entonces (y, x) ∉  R";
    opcionA= "Transitiva";
    opcionB= "Antisimétrica";
    opcionC= "Reflexiva";
    opcionD= "Distributiva";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg38 = new Pregunta (enunciado2, opciones, "Antisimétrica", "Facil", "Relaciones");
    listaPreg.add(preg38);
    
    
    //Pregunta 39   
    opciones = new ArrayList();
    String enunciado39="Una manera informativa de visualizar una relación en un conjunto es dibujar su:";
    opcionA= "Digráfica";
    opcionB= "Función";
    opcionC= "Matriz";
    opcionD= "Ninguna de las opciones es correcta";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg39 = new Pregunta (enunciado3, opciones, "Digráfica", "Facil", " Relaciones");
    listaPreg.add(preg39);

    
    
    //Pregunta 40;
    opciones = new ArrayList();
    String enunciado40="Una relación R en un conjunto X se llama orden parcial si R es: ";
    opcionA= "reflexiva, antisimétrica y transitiva";
    opcionB= "reflexiva y antisimétrica";
    opcionC= "reflexiva y transitiva";
    opcionD= "transitiva";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg40 = new Pregunta (enunciado4, opciones, "reflexiva, antisimétrica y transitiva", "Facil", "Relaciones");
    listaPreg.add(preg40);

    
 

    
    //Pregunta 41
    opciones = new ArrayList();
    String enunciado41="Sea R una relación de X a Y. La inversa de R, denotada por R^(-1) , es la relación de Y a X definida por:";
    opcionA= "R^(-1)={(x,y) | (y,x)∈R";
    opcionB= "R^(-1)={(y,y) | (x,x)∈R";
    opcionC= "R^(-1)={(y,x) | (x,y)∈R";
    opcionD= "R^(-1)={(y,x) | (y,x)∈R";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg41 = new Pregunta (enunciado6, opciones, "R^(-1)={(y,x) | (x,y)∈R", "Medio", "Relaciones");
    listaPreg.add(preg41);
    
    //Pregunta 42
    
    opciones = new ArrayList();
    String enunciado42="Sea R_1una relación de X a Y y R_2 una relación de Y a Z. La composición de R_1 y R_2 , denotada por R_2∘R_1 , es la relación de X a Z definida por:";
    opcionA= "R_2∘R_1={(x,z) | (x,x)∈R_1  y (y,z)∈R_2  para alguna y∈Y}";
    opcionB= "R_2∘R_1={(x,z) | (x,y)∈R_1  y (y,z)∈R_1  para alguna y∈Y}";
    opcionC= "R_2∘R_1={(x,z) | (y,x)∈R_1  y (y,z)∈R_2  para alguna y∈Y)}";
    opcionD= "R_2∘R_1={(x,z) | (x,y)∈R_1  y (y,z)∈R_2  para alguna y∈Y})";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg42= new Pregunta (enunciado7, opciones, "	R_2∘R_1={(x,z)|(x,y)∈R_1  y (y,z)∈R_2  para alguna y∈Y}", "Medio", "Relaciones");
    listaPreg.add(preg42);
    
    
   //Pregunta 43
    opciones = new ArrayList();
    String enunciado43="Si se define una relación R de X = {2, 3, 4} a Y = {3, 4, 5, 6, 7} por (x, y) ∈ R si x divide a y se obtiene R = {(2, 4), (2, 6), (3, 3), (3, 6), (4, 4)} El inverso de esta relacion es :";
    opcionA= "R^(-1)={(4,2),(2,6),(3,3),(6,3),(4,4)";
    opcionB= "R^(-1)={(2,2),(6,2),(3,3),(6,3),(4,4)";
    opcionC= "R^(-1)={(4,2),(2,6),(3,3),(3,6),(4,4)";
    opcionD= "R^(-1)={(4,2),(6,2),(3,3),(6,3),(4,4)";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg43 = new Pregunta (enunciado8, opciones, "	R^(-1)={(4,2),(6,2),(3,3),(6,3),(4,4)", "Medio", "Relaciones");
    listaPreg.add(preg43);
    
    
    //Pregunta 44
    opciones = new ArrayList();
    String enunciado44="Sean las R_1 y R_2 relaciones en {1, 2, 3, 4} dadas por  R_1 = {(1, 1), (1, 2), (3, 4), (4, 2)}   y  R_2= {(1, 1), (2, 1), (3, 1), (4, 4), (2, 2)}. Los elementos de R_2∘R_1 son:";
    opcionA= "R_2∘R_1= {(1, 1), (1, 2), (2, 1), (2, 2), (1, 3), (3, 2), (4, 2)}";
    opcionB= "R_2∘R_1= {(1, 1), (1, 2), (3, 4), (4, 1), (4, 2)}";
    opcionC= "R_2∘R_1={(1, 1), (1, 2), (2, 1), (2, 2), (3, 1), (3, 2), (4, 2)}";
    opcionD= "R_2∘R_1= {(1, 1), (1, 2), (4, 4), (4, 1), (4, 2)}";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg44 = new Pregunta (enunciado9, opciones, "R_2∘R_1= {(1, 1), (1, 2), (3, 4), (4, 1), (4, 2)}", "Medio", "Relaciones");
    listaPreg.add(preg44);
    
    
    //Pregunta 45
    opciones= new ArrayList();
    String enunciado45="La composición de las relaciones  R_1= {(1, 2), (1, 6), (2, 4), (3, 4), (3, 6), (3, 8)}  y  R_2= {(2, u), (4, s), (4, t), (6, t), (8, u)} es:";
    opcionA= "	R_2∘R_1={(1, u), (1, t), (2, s), (2, t), (3, s), (3, t), (3, u)}";
    opcionB= "	R_2∘R_1={(u,1), (1, t), (2, s), (2, t), (3, s), (3, t), (3, u)}";
    opcionC= "	R_2∘R_1={(1, u), (1, t), (2, s), (t,2), (3, s), (3, t), (3, u)}";
    opcionD= "	R_2∘R_1={(u, 1), (t, 1), (s, 2), (t, 2), (s, 3), (t, 3), (u, 3)}";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg45 = new Pregunta (enunciado10, opciones, "	R_2∘R_1={(1, u), (1, t), (2, s), (2, t), (3, s), (3, t), (3, u)}", "Dificil", "Relaciones");
    listaPreg.add(preg45);
    
    
    //Pregunta 46
    opciones= new ArrayList();
    String enunciado46="¿Cómo se denota una clase de equivalencia?";
    opcionA= "{(y, x) | (x, y) ∈ R}";
    opcionB= "{x ∈ X | (x, y) ∈ R para alguna y ∈ Y}";
    opcionC= "{x ∈ X | xRa}";
    opcionD= "{x ∈ X | xRy}";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg46 = new Pregunta (enunciado11, opciones, "{x ∈ X | xRa}", "Dificil", "Relaciones");
    listaPreg.add(preg46);
    
    
    //Pregunta 47
    
   opciones = new ArrayList();
    String enunciado47="A partir de la matriz de una relación, ¿cómo se puede determinar si la relación es reflexiva?";
    opcionA= " si y sólo si siempre que el elemento i, j en A^2 es diferente de cero, el elemento i,j en A también es diferente de cero";
    opcionB= "si y sólo si su matriz tiene ceros en la diagonal principal";
    opcionC= "si y sólo si su matriz A satisface lo siguiente: Para toda i y j, el elemento ij de A es igual al elemento ji de A";
    opcionD= "si y sólo si su matriz tiene unos en la diagonal principal";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg47 = new Pregunta (enunciado47, opciones, "si y sólo si su matriz tiene unos en la diagonal principal", "Dificil", "Relaciones");
    listaPreg.add(preg47);
    
    
    //Pregunta 48
    
    opciones = new ArrayList();
    String enunciado48=" ¿Cuando una relación R sobre un conjunto X se llama simétrica?";
    opcionA= "Si para toda x, y ∈ X, si (x, y) ∈ R, entonces (y, x) ∉ R.";
    opcionB= "Si para toda x, y ∈ X, si (x, y) ∈ R, entonces (y, x) ∈ R";
    opcionC= "Si para toda x, y ∈ X, si (x, y) ∈ R y x ≠ y, entonces (y, x) € R";
    opcionD= "Si para toda x, y ∈ X, si (x, y) ∈ R y x = y, entonces (y, x) € R";
    opciones.add(opcionA);
    opciones.add(opcionB);
    opciones.add(opcionC);
    opciones.add(opcionD);

    Pregunta preg48 = new Pregunta (enunciado48, opciones, "Si para toda x, y ∈ X, si (x, y) ∈ R, entonces (y, x) ∈ R.", "Dificil", "Relaciones");
    listaPreg.add(preg48);
    
    
  }  
}  